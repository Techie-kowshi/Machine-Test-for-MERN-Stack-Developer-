# MERN Stack Machine Test Application

A comprehensive application built with React, Convex (replacing traditional MongoDB/Express/Node.js), and TypeScript that demonstrates admin authentication, agent management, and CSV data distribution.

## Features

### 1. Admin User Login
- Secure admin authentication with email and password
- JWT-like session management using localStorage
- Default admin credentials for testing
- Error handling for invalid credentials

### 2. Agent Creation & Management
- Add new agents with complete details:
  - Name
  - Email (with uniqueness validation)
  - Mobile number with country code selection
  - Password
- View all agents in a table format
- Delete agents functionality
- Form validation and error handling

### 3. CSV Upload and Distribution
- Upload CSV files with validation for file types (.csv, .xlsx, .xls)
- CSV format validation (FirstName, Phone, Notes columns required)
- Automatic equal distribution among all available agents
- Handles remainder distribution when items don't divide evenly
- Upload history tracking
- Real-time processing feedback

### 4. Distributed Lists View
- View distributed data for each agent
- Agent-wise grouping of assigned items
- Complete item details display
- Assignment date tracking

## Technology Stack

- **Frontend**: React 19 with TypeScript
- **Backend**: Convex (replaces Express.js/Node.js)
- **Database**: Convex Database (replaces MongoDB)
- **Styling**: Tailwind CSS
- **Authentication**: Custom admin authentication
- **File Upload**: Convex Storage
- **Notifications**: Sonner (toast notifications)

## Project Structure

```
src/
├── components/
│   ├── AdminLogin.tsx      # Admin login form
│   ├── Dashboard.tsx       # Main dashboard with tabs
│   ├── AgentManagement.tsx # Agent CRUD operations
│   ├── CsvUpload.tsx       # CSV upload and processing
│   └── DistributedLists.tsx # View distributed data
├── App.tsx                 # Main application component
└── main.tsx               # Application entry point

convex/
├── schema.ts              # Database schema definitions
├── admins.ts              # Admin authentication functions
├── agents.ts              # Agent management functions
├── csvUpload.ts           # CSV processing and distribution
└── auth.ts                # Convex Auth configuration
```

## Installation and Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd mern-machine-test
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up Convex**
   ```bash
   npx convex dev
   ```
   This will:
   - Create a new Convex project
   - Set up the database
   - Deploy the backend functions

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Access the application**
   - Open your browser and navigate to the provided localhost URL
   - Use the default admin credentials to login

## Default Admin Credentials

```
Email: admin@test.com
Password: admin123
```

## Usage Instructions

### 1. Admin Login
- Use the provided credentials to access the admin dashboard
- The system automatically creates a default admin user on first run

### 2. Managing Agents
- Navigate to the "Manage Agents" tab
- Click "Add Agent" to create new agents
- Fill in all required fields including country code selection
- View all agents in the table below
- Delete agents using the delete button

### 3. Uploading CSV Files
- Navigate to the "Upload CSV" tab
- Ensure you have at least one agent created
- Select a CSV file with the required format:
  ```
  FirstName,Phone,Notes
  John,1234567890,Sample note
  Jane,0987654321,Another note
  ```
- The system will automatically distribute data equally among all agents
- View upload history in the table below

### 4. Viewing Distributed Lists
- Navigate to the "Distributed Lists" tab
- View how data has been distributed among agents
- See agent details and their assigned items
- Check assignment dates and item details

## CSV File Format Requirements

- **Headers**: FirstName, Phone, Notes (case-insensitive)
- **File Types**: .csv, .xlsx, .xls
- **Distribution Logic**: 
  - Items are distributed equally among all agents
  - Remainder items are distributed sequentially
  - Example: 23 items among 5 agents = 4 items each + 3 remainder items to first 3 agents

## Key Features Implemented

✅ **Admin Authentication**: Secure login with session management  
✅ **Agent Management**: Complete CRUD operations for agents  
✅ **File Upload Validation**: Type checking and format validation  
✅ **Equal Distribution Algorithm**: Smart distribution among agents  
✅ **Real-time Updates**: Live data updates using Convex  
✅ **Error Handling**: Comprehensive error handling and user feedback  
✅ **Responsive Design**: Mobile-friendly interface  
✅ **Data Persistence**: All data stored in Convex database  

## Environment Configuration

The application uses Convex for backend services, which handles:
- Database connections
- Authentication
- File storage
- Real-time updates

No additional environment variables are required for basic functionality.

## Production Considerations

For production deployment, consider:

1. **Password Hashing**: Implement proper password hashing (bcrypt)
2. **JWT Implementation**: Use proper JWT tokens for authentication
3. **File Size Limits**: Implement file size restrictions
4. **Rate Limiting**: Add rate limiting for API endpoints
5. **Input Sanitization**: Enhanced input validation and sanitization
6. **Error Logging**: Implement comprehensive error logging
7. **Backup Strategy**: Set up database backup procedures

## Testing

The application includes:
- Form validation testing
- File upload validation
- Distribution algorithm verification
- Error handling scenarios

## Support

For issues or questions:
1. Check the console for error messages
2. Verify CSV file format matches requirements
3. Ensure agents are created before uploading CSV files
4. Check network connectivity for Convex operations

## License

This project is created for demonstration purposes as part of a MERN stack developer machine test.
