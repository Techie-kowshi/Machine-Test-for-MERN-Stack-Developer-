import { useState, useRef } from "react";
import { useMutation, useQuery, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function CsvUpload() {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateUploadUrl = useMutation(api.csvUpload.generateUploadUrl);
  const processCsvUpload = useAction(api.csvUpload.processCsvUpload);
  const csvUploads = useQuery(api.csvUpload.getAllCsvUploads) || [];
  const agents = useQuery(api.agents.getAllAgents) || [];

  const downloadSampleCSV = () => {
    const sampleData = `FirstName,Phone,Notes
John Doe,1234567890,Sales lead from website
Jane Smith,0987654321,Interested in premium package
Mike Johnson,5555551234,Follow up next week
Sarah Wilson,7777778888,Existing customer referral
David Brown,9999990000,Demo scheduled for Monday`;

    const blob = new Blob([sampleData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample_data.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    toast.success('Sample CSV downloaded!');
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    console.log("Selected file:", file.name, file.type, file.size);

    // Validate file type
    const allowedTypes = ['.csv', '.txt'];
    const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
    
    if (!allowedTypes.includes(fileExtension)) {
      toast.error('Invalid file type. Please upload CSV or TXT files only.');
      return;
    }

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('File too large. Please upload files smaller than 10MB.');
      return;
    }

    if (agents.length === 0) {
      toast.error('Please add at least one agent before uploading CSV files.');
      return;
    }

    setIsUploading(true);
    setUploadProgress("Preparing upload...");

    try {
      // Step 1: Get upload URL
      setUploadProgress("Getting upload URL...");
      const uploadUrl = await generateUploadUrl();
      console.log("Upload URL obtained");

      // Step 2: Upload file
      setUploadProgress("Uploading file...");
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type || "text/csv" },
        body: file,
      });

      if (!result.ok) {
        const errorText = await result.text();
        console.error("Upload failed:", result.status, errorText);
        throw new Error(`Upload failed: ${result.statusText}`);
      }

      const { storageId } = await result.json();
      console.log("File uploaded with storage ID:", storageId);

      // Step 3: Process the uploaded file
      setUploadProgress("Processing CSV file...");
      const processResult = await processCsvUpload({
        storageId,
        fileName: file.name,
      });

      console.log("Processing result:", processResult);

      toast.success(
        `CSV processed successfully! ${processResult.totalRecords} records distributed among ${processResult.agentsCount} agents.`
      );

      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error: any) {
      console.error("Upload error:", error);
      toast.error(error.message || 'Failed to upload and process CSV');
    } finally {
      setIsUploading(false);
      setUploadProgress("");
    }
  };

  return (
    <div>
      <h2 className="text-xl font-semibold mb-6">CSV Upload & Distribution</h2>

      {/* Upload Section */}
      <div className="bg-gray-50 p-6 rounded-lg mb-6">
        <h3 className="text-lg font-medium mb-4">Upload CSV File</h3>
        
        <div className="mb-4 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-blue-800 mb-2">CSV Format Requirements:</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• <strong>Headers:</strong> FirstName, Phone, Notes (case-insensitive)</li>
            <li>• <strong>File types:</strong> .csv, .txt</li>
            <li>• <strong>Separators:</strong> Comma (,) or semicolon (;)</li>
            <li>• <strong>Example:</strong></li>
          </ul>
          <div className="mt-2 p-2 bg-white rounded text-xs font-mono">
            FirstName,Phone,Notes<br/>
            John,1234567890,Sample note<br/>
            Jane,0987654321,Another note
          </div>
          <button
            onClick={downloadSampleCSV}
            className="mt-2 px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700"
          >
            Download Sample CSV
          </button>
        </div>

        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select CSV File
          </label>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.txt"
            onChange={handleFileUpload}
            disabled={isUploading}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 disabled:opacity-50"
          />
        </div>

        {isUploading && (
          <div className="mb-4 p-4 bg-yellow-50 rounded-lg">
            <div className="flex items-center space-x-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              <span className="text-sm text-gray-600">{uploadProgress}</span>
            </div>
          </div>
        )}

        {agents.length === 0 && (
          <div className="mt-4 p-4 bg-yellow-50 rounded-lg">
            <p className="text-yellow-800 text-sm">
              ⚠️ No agents available. Please add agents first before uploading CSV files.
            </p>
          </div>
        )}

        {agents.length > 0 && (
          <div className="mt-4 p-4 bg-green-50 rounded-lg">
            <p className="text-green-800 text-sm">
              ✅ Ready to upload! {agents.length} agent(s) available for data distribution.
            </p>
          </div>
        )}
      </div>

      {/* Upload History */}
      <div>
        <h3 className="text-lg font-medium mb-4">Upload History</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  File Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total Records
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Upload Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {csvUploads.map((upload) => (
                <tr key={upload._id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {upload.fileName}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {upload.totalRecords}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(upload._creationTime).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                      Processed
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {csvUploads.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No CSV files uploaded yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
