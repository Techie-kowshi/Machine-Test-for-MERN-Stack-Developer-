import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function DistributedLists() {
  const distributedLists = useQuery(api.csvUpload.getDistributedLists, {}) || {};
  const csvUploads = useQuery(api.csvUpload.getAllCsvUploads) || [];

  const agentEntries = Object.entries(distributedLists);

  return (
    <div>
      <h2 className="text-xl font-semibold mb-6">Distributed Lists</h2>

      {agentEntries.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          No distributed lists found. Upload a CSV file to get started.
        </div>
      ) : (
        <div className="space-y-6">
          {agentEntries.map(([agentId, data]: [string, any]) => (
            <div key={agentId} className="bg-white border rounded-lg p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  {data.agent.name}
                </h3>
                <div className="text-sm text-gray-500">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                    {data.items.length} items assigned
                  </span>
                </div>
              </div>

              <div className="mb-4 text-sm text-gray-600">
                <p>Email: {data.agent.email}</p>
                <p>Mobile: {data.agent.countryCode} {data.agent.mobileNumber}</p>
              </div>

              {data.items.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          First Name
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Phone
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Notes
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Assigned Date
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {data.items.map((item: any) => (
                        <tr key={item._id}>
                          <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900">
                            {item.firstName}
                          </td>
                          <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                            {item.phone}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-500">
                            {item.notes}
                          </td>
                          <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                            {new Date(item.assignedAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-gray-500 text-sm">No items assigned to this agent yet.</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
