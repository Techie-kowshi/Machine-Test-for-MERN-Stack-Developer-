import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { Dashboard } from "./components/Dashboard";
import { AdminLogin } from "./components/AdminLogin";
import { useState, useEffect } from "react";

export default function App() {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminData, setAdminData] = useState(null);

  useEffect(() => {
    // Check if admin is logged in from localStorage
    const adminInfo = localStorage.getItem('adminInfo');
    if (adminInfo) {
      setAdminData(JSON.parse(adminInfo));
      setIsAdminLoggedIn(true);
    }
  }, []);

  const handleAdminLogin = (admin: any) => {
    setAdminData(admin);
    setIsAdminLoggedIn(true);
    localStorage.setItem('adminInfo', JSON.stringify(admin));
  };

  const handleAdminLogout = () => {
    setAdminData(null);
    setIsAdminLoggedIn(false);
    localStorage.removeItem('adminInfo');
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm h-16 flex justify-between items-center border-b shadow-sm px-4">
        <h2 className="text-xl font-semibold text-blue-600">MERN Stack Machine Test</h2>
        {isAdminLoggedIn && (
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">Welcome, {(adminData as any)?.name}</span>
            <button
              onClick={handleAdminLogout}
              className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition-colors"
            >
              Logout
            </button>
          </div>
        )}
      </header>
      <main className="flex-1 p-8">
        {!isAdminLoggedIn ? (
          <AdminLogin onLogin={handleAdminLogin} />
        ) : (
          <Dashboard adminData={adminData} />
        )}
      </main>
      <Toaster />
    </div>
  );
}
