import { v } from "convex/values";
import { query, mutation } from "./_generated/server";

// Add new agent
export const addAgent = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    mobileNumber: v.string(),
    countryCode: v.string(),
    password: v.string(),
  },
  handler: async (ctx, args) => {
    // Get or create default admin for demo
    let defaultAdmin = await ctx.db
      .query("admins")
      .withIndex("by_email", (q) => q.eq("email", "admin@test.com"))
      .first();
    
    if (!defaultAdmin) {
      const adminId = await ctx.db.insert("admins", {
        email: "admin@test.com",
        password: "admin123",
        name: "Admin User",
      });
      defaultAdmin = await ctx.db.get(adminId);
    }

    // Check if agent with this email already exists
    const existingAgent = await ctx.db
      .query("agents")
      .withIndex("by_email", (q) => q.eq("email", args.email))
      .first();

    if (existingAgent) {
      throw new Error("Agent with this email already exists");
    }

    const agentId = await ctx.db.insert("agents", {
      name: args.name,
      email: args.email,
      mobileNumber: args.mobileNumber,
      countryCode: args.countryCode,
      password: args.password,
      createdBy: defaultAdmin!._id,
    });

    return agentId;
  },
});

// Get all agents
export const getAllAgents = query({
  args: {},
  handler: async (ctx) => {
    const agents = await ctx.db.query("agents").collect();
    return agents.map(agent => ({
      ...agent,
      password: undefined,
    }));
  },
});

// Delete agent
export const deleteAgent = mutation({
  args: {
    agentId: v.id("agents"),
  },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.agentId);
    return null;
  },
});
