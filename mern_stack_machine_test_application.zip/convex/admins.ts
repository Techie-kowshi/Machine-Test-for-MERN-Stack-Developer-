import { v } from "convex/values";
import { query, mutation } from "./_generated/server";

// Create default admin user
export const createDefaultAdmin = mutation({
  args: {},
  handler: async (ctx) => {
    // Check if admin already exists
    const existingAdmin = await ctx.db
      .query("admins")
      .withIndex("by_email", (q) => q.eq("email", "admin@test.com"))
      .first();

    if (!existingAdmin) {
      await ctx.db.insert("admins", {
        email: "admin@test.com",
        password: "admin123", // In production, this would be hashed
        name: "Admin User",
      });
    }
    return null;
  },
});

// Admin login
export const adminLogin = mutation({
  args: {
    email: v.string(),
    password: v.string(),
  },
  handler: async (ctx, args) => {
    const admin = await ctx.db
      .query("admins")
      .withIndex("by_email", (q) => q.eq("email", args.email))
      .first();

    if (!admin || admin.password !== args.password) {
      throw new Error("Invalid email or password");
    }

    return {
      id: admin._id,
      email: admin.email,
      name: admin.name,
    };
  },
});

// Get current admin
export const getCurrentAdmin = query({
  args: {},
  handler: async (ctx) => {
    // For this demo, we'll return the default admin
    const admin = await ctx.db
      .query("admins")
      .withIndex("by_email", (q) => q.eq("email", "admin@test.com"))
      .first();
    return admin;
  },
});
