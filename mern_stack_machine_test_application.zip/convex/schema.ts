import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Admin users table
  admins: defineTable({
    email: v.string(),
    password: v.string(), // In production, this would be hashed
    name: v.string(),
  }).index("by_email", ["email"]),

  // Agents table
  agents: defineTable({
    name: v.string(),
    email: v.string(),
    mobileNumber: v.string(),
    countryCode: v.string(),
    password: v.string(), // In production, this would be hashed
    createdBy: v.id("admins"),
  }).index("by_email", ["email"]),

  // CSV uploads table
  csvUploads: defineTable({
    fileName: v.string(),
    uploadedBy: v.id("admins"),
    totalRecords: v.number(),
    storageId: v.id("_storage"),
  }),

  // Distributed lists table
  distributedLists: defineTable({
    agentId: v.id("agents"),
    csvUploadId: v.id("csvUploads"),
    firstName: v.string(),
    phone: v.string(),
    notes: v.string(),
    assignedAt: v.number(),
  }).index("by_agent", ["agentId"])
    .index("by_csv_upload", ["csvUploadId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
