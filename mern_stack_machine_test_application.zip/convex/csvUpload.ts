import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { api } from "./_generated/api";

// Generate upload URL for CSV file
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

// Process uploaded CSV and distribute among agents
export const processCsvUpload = action({
  args: {
    storageId: v.id("_storage"),
    fileName: v.string(),
  },
  handler: async (ctx, args): Promise<{
    csvUploadId: any;
    totalRecords: number;
    agentsCount: number;
  }> => {
    // Get the file from storage
    const file = await ctx.storage.get(args.storageId);
    if (!file) {
      throw new Error("File not found");
    }

    // Convert blob to text
    const text = await file.text();
    console.log("File content:", text.substring(0, 200)); // Debug log
    
    // Parse CSV - handle different line endings and formats
    const lines = text.split(/\r?\n/).filter(line => line.trim());
    console.log("Total lines:", lines.length); // Debug log
    
    if (lines.length === 0) {
      throw new Error('CSV file is empty');
    }

    // Parse headers - handle quoted fields and different separators
    const headerLine = lines[0];
    let headers: string[];
    
    // Try comma first, then semicolon
    if (headerLine.includes(',')) {
      headers = headerLine.split(',').map(h => h.trim().replace(/['"]/g, ''));
    } else if (headerLine.includes(';')) {
      headers = headerLine.split(';').map(h => h.trim().replace(/['"]/g, ''));
    } else {
      throw new Error('Invalid CSV format. Headers must be separated by commas or semicolons.');
    }
    
    console.log("Headers found:", headers); // Debug log
    
    // Validate headers - more flexible matching
    const requiredHeaders = ['firstname', 'phone', 'notes'];
    const headerMap: { [key: string]: number } = {};
    
    requiredHeaders.forEach(required => {
      const index = headers.findIndex(h => 
        h.toLowerCase().includes(required) || 
        required.includes(h.toLowerCase())
      );
      if (index === -1) {
        throw new Error(`Missing required header: ${required}. Found headers: ${headers.join(', ')}`);
      }
      headerMap[required] = index;
    });

    console.log("Header mapping:", headerMap); // Debug log

    // Parse data rows
    const dataRows = [];
    const separator = headerLine.includes(',') ? ',' : ';';
    
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue; // Skip empty lines
      
      // Split by separator and handle quoted fields
      const values = line.split(separator).map(v => v.trim().replace(/^["']|["']$/g, ''));
      
      if (values.length >= Math.max(...Object.values(headerMap)) + 1) {
        const firstName = values[headerMap.firstname]?.trim();
        const phone = values[headerMap.phone]?.trim();
        const notes = values[headerMap.notes]?.trim() || '';
        
        if (firstName && phone) {
          dataRows.push({
            firstName,
            phone,
            notes,
          });
        }
      }
    }

    console.log("Parsed data rows:", dataRows.length); // Debug log

    if (dataRows.length === 0) {
      throw new Error('No valid data rows found in CSV. Please check the format and ensure data is present.');
    }

    // Get all agents
    const agents: any[] = await ctx.runQuery(api.agents.getAllAgents);
    if (agents.length === 0) {
      throw new Error('No agents available for distribution. Please add agents first.');
    }

    console.log("Available agents:", agents.length); // Debug log

    // Create CSV upload record
    const csvUploadId: any = await ctx.runMutation(api.csvUpload.createCsvUploadRecord, {
      fileName: args.fileName,
      totalRecords: dataRows.length,
      storageId: args.storageId,
    });

    // Distribute data among agents
    const itemsPerAgent = Math.floor(dataRows.length / agents.length);
    const remainingItems = dataRows.length % agents.length;

    console.log(`Distributing ${dataRows.length} items among ${agents.length} agents`); // Debug log
    console.log(`${itemsPerAgent} items per agent, ${remainingItems} remainder items`); // Debug log

    let currentIndex = 0;
    for (let i = 0; i < agents.length; i++) {
      const agent = agents[i];
      const itemsForThisAgent = itemsPerAgent + (i < remainingItems ? 1 : 0);
      
      console.log(`Assigning ${itemsForThisAgent} items to agent ${agent.name}`); // Debug log
      
      for (let j = 0; j < itemsForThisAgent; j++) {
        if (currentIndex < dataRows.length) {
          const data = dataRows[currentIndex];
          await ctx.runMutation(api.csvUpload.createDistributedListItem, {
            agentId: agent._id,
            csvUploadId,
            firstName: data.firstName,
            phone: data.phone,
            notes: data.notes,
          });
          currentIndex++;
        }
      }
    }

    console.log("Distribution completed successfully"); // Debug log

    return {
      csvUploadId,
      totalRecords: dataRows.length,
      agentsCount: agents.length,
    };
  },
});

// Create CSV upload record
export const createCsvUploadRecord = mutation({
  args: {
    fileName: v.string(),
    totalRecords: v.number(),
    storageId: v.id("_storage"),
  },
  handler: async (ctx, args) => {
    // Get or create default admin for demo
    let defaultAdmin = await ctx.db
      .query("admins")
      .withIndex("by_email", (q) => q.eq("email", "admin@test.com"))
      .first();
    
    if (!defaultAdmin) {
      const adminId = await ctx.db.insert("admins", {
        email: "admin@test.com",
        password: "admin123",
        name: "Admin User",
      });
      defaultAdmin = await ctx.db.get(adminId);
    }

    return await ctx.db.insert("csvUploads", {
      fileName: args.fileName,
      uploadedBy: defaultAdmin!._id,
      totalRecords: args.totalRecords,
      storageId: args.storageId,
    });
  },
});

// Create distributed list item
export const createDistributedListItem = mutation({
  args: {
    agentId: v.id("agents"),
    csvUploadId: v.id("csvUploads"),
    firstName: v.string(),
    phone: v.string(),
    notes: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("distributedLists", {
      agentId: args.agentId,
      csvUploadId: args.csvUploadId,
      firstName: args.firstName,
      phone: args.phone,
      notes: args.notes,
      assignedAt: Date.now(),
    });
  },
});

// Get all CSV uploads
export const getAllCsvUploads = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("csvUploads").order("desc").collect();
  },
});

// Get distributed lists for all agents
export const getDistributedLists = query({
  args: {
    csvUploadId: v.optional(v.id("csvUploads")),
  },
  handler: async (ctx, args) => {
    let distributedLists;
    
    if (args.csvUploadId) {
      distributedLists = await ctx.db
        .query("distributedLists")
        .withIndex("by_csv_upload", (q) => q.eq("csvUploadId", args.csvUploadId!))
        .collect();
    } else {
      distributedLists = await ctx.db.query("distributedLists").collect();
    }
    
    // Group by agent
    const agentLists: Record<string, any> = {};
    const agents = await ctx.db.query("agents").collect();
    
    for (const agent of agents) {
      agentLists[agent._id] = {
        agent: agent,
        items: distributedLists.filter((item: any) => item.agentId === agent._id),
      };
    }

    return agentLists;
  },
});
